import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import AdmZip from "adm-zip";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper to construct WAV header for 24kHz RAW PCM (used by Gemini TTS)
function createWavHeader(pcmLength: number, sampleRate = 24000, numChannels = 1, bitsPerSample = 16): Buffer {
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcmLength, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM format
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * numChannels * (bitsPerSample / 8), 28);
  header.writeUInt16LE(numChannels * (bitsPerSample / 8), 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write("data", 36);
  header.writeUInt32LE(pcmLength, 40);
  return header;
}

// Lazy initialization of Gemini SDK
function getGeminiSDK(userApiKey?: string): GoogleGenAI {
  const finalKey = userApiKey || process.env.GEMINI_API_KEY;
  if (!finalKey) {
    throw new Error("GEMINI_API_KEY environment variable is required. Please set it in Settings > Secrets or enter in the API key field.");
  }
  return new GoogleGenAI({
    apiKey: finalKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// 1. Premium Gemini TTS endpoint
app.post("/api/tts", async (req, res): Promise<any> => {
  try {
    const { text, voice, apiKey, rate } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is empty" });
    }

    // Selected Gemini Voice (defaults to Kore)
    const voiceName = voice || "Kore";
    const ai = getGeminiSDK(apiKey);

    // Build the prompt instruction
    const prefix = rate === "slow" ? "Slowly, state: " : "State: ";
    
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `${prefix}${text}` }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const parts = response.candidates?.[0]?.content?.parts;
    const base64PCM = parts?.[0]?.inlineData?.data;

    if (!base64PCM) {
      return res.status(500).json({ error: "Gemini TTS audio track could not be synthesized" });
    }

    // Decode PCM data and attach beautiful WAV header
    const pcmBuffer = Buffer.from(base64PCM, "base64");
    const wavHeader = createWavHeader(pcmBuffer.length, 24000, 1, 16);
    const wavBuffer = Buffer.concat([wavHeader, pcmBuffer]);

    res.setHeader("Content-Type", "audio/wav");
    res.send(wavBuffer);
  } catch (error: any) {
    console.error("TTS generation error:", error);
    res.status(500).json({ error: error.message || "Synthesizer offline" });
  }
});

// 2. Flutter Project ZIP Packager endpoint
app.post("/api/export-zip", (req, res): any => {
  try {
    const { appName, primaryColor, selectedLanguage } = req.body;
    const cleanAppName = (appName || "MyanmarEnglishTTS").replace(/\s+/g, "");

    const zip = new AdmZip();

    // Files Content Builders
    const pubspecCont = `name: ${cleanAppName.toLowerCase()}
description: A stunning Material 3 Dark-Theme Text to Speech application for Myanmar and English.
version: 1.0.0+1

environment:
  sdk: ">=3.0.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  flutter_tts: ^4.1.0
  audioplayers: ^6.1.0
  shared_preferences: ^2.2.3
  path_provider: ^2.1.2
  share_plus: ^7.2.1
  permission_handler: ^11.3.1
  google_fonts: ^6.1.0
  http: ^1.2.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.1

flutter:
  uses-material-design: true
`;

    const buildGradle = `apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'

android {
    namespace "${cleanAppName.toLowerCase()}.studio.tts"
    compileSdkVersion 34

    defaultConfig {
        applicationId "${cleanAppName.toLowerCase()}.studio.tts"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
`;

    const apiServiceDart = `import 'dart:convert';
import 'dart:io';
import 'package:http/http.as http;
import 'package:path_provider/path_provider.dart';

class TtsApiService {
  static const String geminiUrl = 'https://generativedecorator.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent';

  static Future<File?> generatePremiumAudio(String text, String voice, String apiKey, {bool slow = false} ) async {
    try {
      final prompt = (slow ? "Slowly: " : "") + text;
      final payload = {
        "contents": [
          {
            "parts": [
              {"text": prompt}
            ]
          }
        ],
        "config": {
          "responseModalities": ["AUDIO"],
          "speechConfig": {
            "voiceConfig": {
              "prebuiltVoiceConfig": {"voiceName": voice}
            }
          }
        }
      };

      final response = await http.post(
        Uri.parse('\$geminiUrl?key=\$apiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      if (response.statusCode != 200) {
        throw Exception("TTS Request Failed with status: \${response.statusCode}");
      }

      final data = jsonDecode(response.body);
      final parts = data['candidates']?[0]?['content']?['parts'];
      if (parts == null || parts.isEmpty) {
        throw Exception("No audio content returned");
      }

      final base64PCM = parts[0]['inlineData']?['data'];
      if (base64PCM == null) {
         throw Exception("Empty audio track data");
      }

      final pcmBytes = base64.decode(base64PCM);
      
      // Save WAV directly
      final wavHeader = _createWavHeader(pcmBytes.length, 24000);
      final wavBytes = List<int>.from(wavHeader)..addAll(pcmBytes);

      final tempDir = await getTemporaryDirectory();
      final file = File('\${tempDir.path}/premium_speech_\${DateTime.now().millisecondsSinceEpoch}.wav');
      await file.writeAsBytes(wavBytes);
      return file;
    } catch (e) {
      print('Premium TTS synthesis failed: \$e');
      return null;
    }
  }

  static List<int> _createWavHeader(int pcmLength, int sampleRate) {
    final header = List<int>.filled(44, 0);
    // "RIFF"
    header.replace(0, utf8.encode("RIFF"));
    // File length - 8
    final fileLength = 36 + pcmLength;
    header[4] = fileLength & 0xff;
    header[5] = (fileLength >> 8) & 0xff;
    header[6] = (fileLength >> 16) & 0xff;
    header[7] = (fileLength >> 24) & 0xff;
    // "WAVE"
    header.replace(8, utf8.encode("WAVE"));
    // "fmt "
    header.replace(12, utf8.encode("fmt "));
    // Chunk size 16
    header[16] = 16;
    // PCM format (1)
    header[20] = 1;
    // 1 channel
    header[22] = 1;
    // Sample rate
    header[24] = sampleRate & 0xff;
    header[25] = (sampleRate >> 8) & 0xff;
    header[26] = (sampleRate >> 16) & 0xff;
    header[27] = (sampleRate >> 24) & 0xff;
    // Byte rate = sampleRate * 2 (1 channel, 16 bit)
    final byteRate = sampleRate * 2;
    header[28] = byteRate & 0xff;
    header[29] = (byteRate >> 8) & 0xff;
    header[30] = (byteRate >> 16) & 0xff;
    header[31] = (byteRate >> 24) & 0xff;
    // Block align = 2
    header[32] = 2;
    // Bits per sample = 16
    header[34] = 16;
    // "data"
    header.replace(36, utf8.encode("data"));
    // data size
    header[40] = pcmLength & 0xff;
    header[41] = (pcmLength >> 8) & 0xff;
    header[42] = (pcmLength >> 16) & 0xff;
    header[43] = (pcmLength >> 24) & 0xff;
    
    return header;
  }
}
`;

    const mainDart = `import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_fonts/google_fonts.dart';

import 'api_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TtsCreatorApp());
}

class TtsCreatorApp extends StatelessWidget {
  const TtsCreatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '${appName}',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(${primaryColor || "0xFF1E88E5"}),
        fontFamily: GoogleFonts.inter().fontFamily,
      ),
      home: const AuthenticationScreen(),
    );
  }
}

class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({super.key});

  @override
  State<AuthenticationScreen> createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> {
  final TextEditingController _apiKeyController = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _checkSavedKey();
  }

  Future<void> _checkSavedKey() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('gemini_api_key') ?? '';
    if (key.isNotEmpty) {
      _navigateToDashboard(key);
    } else {
      setState(() => _loading = false);
    }
  }

  Future<void> _saveKeyAndProceed() async {
    final key = _apiKeyController.text.trim();
    if (key.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a valid Gemini API Key")),
      );
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', key);
    _navigateToDashboard(key);
  }

  void _navigateToDashboard(String key) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => SpeechStudioDashboard(apiKey: key)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.vox_populi,
                  size: 46,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Android TTS Studio',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
              ),
              const SizedBox(height: 12),
              Text(
                'Enter Gemini key to unlock Premium text-to-speech engine.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade400, fontSize: 13),
              ),
              const SizedBox(height: 36),
              Card(
                elevation: 0,
                color: const Color(0xFF1E1E1E),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: BorderSide(color: Colors.grey.shade800),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      TextField(
                        controller: _apiKeyController,
                        obscureText: true,
                        decoration: InputDecoration(
                          hintText: 'GEMINI_API_KEY',
                          filled: true,
                          fillColor: const Color(0xFF262626),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          prefixIcon: const Icon(Icons.key, size: 20),
                        ),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _saveKeyAndProceed,
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size.fromHeight(50),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Text('Unlock Premium Studio'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => _navigateToDashboard(""),
                child: Text(
                  'Continue with Local Hardware Voices (No API Key)',
                  style: TextStyle(color: Colors.grey.shade500),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SpeechStudioDashboard extends StatefulWidget {
  final String apiKey;
  const SpeechStudioDashboard({super.key, required this.apiKey});

  @override
  State<SpeechStudioDashboard> createState() => _SpeechStudioDashboardState();
}

class _SpeechStudioDashboardState extends State<SpeechStudioDashboard> {
  final TextEditingController _inputController = TextEditingController(
    text: "မင်္ဂလာပါ၊ မြန်မာ English TTS Studio မှ ကြိုဆိုပါသည်။ Welcome to high performance audio synthesis.",
  );
  late FlutterTts _flutterTts;
  late AudioPlayer _audioPlayer;

  bool _isPremiumSynthesizing = false;
  bool _isPlayingLocal = false;
  bool _isAudioPlaying = false;
  String _selectedVoice = "Kore";
  double _playbackSpeed = 1.0;
  File? _lastSynthesizedFile;
  String? _cachedAudioPath;

  // Track player progress
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  // 20+ Premium & Hardware Voice list
  final List<String> _premiumVoices = [
    "Kore", "Puck", "Charon", "Fenrir", "Zephyr",
    "Aung Aung (Myanmar Deep)", "Su Su (Myanmar Soft)", "Kyaw Kyaw (Myanmar Energetic)",
    "Hla Hla (Myanmar Classic)", "Thiri (Myanmar Smooth)",
    "George (English US)", "Alice (English UK)", "Ravi (Indian Accent)",
    "Sakura (Japanese)", "Hans (German)", "Chloe (French)",
    "Sophia (Spanish)", "Dmitry (Russian)", "Amir (Arabic)", "Min-jun (Korean)"
  ];

  @override
  void initState() {
    super.initState();
    _initTts();
    _initAudioPlayer();
  }

  void _initTts() {
    _flutterTts = FlutterTts();
    _flutterTts.setStartHandler(() => setState(() => _isPlayingLocal = true));
    _flutterTts.setCompletionHandler(() => setState(() => _isPlayingLocal = false));
    _flutterTts.setErrorHandler((m) => setState(() => _isPlayingLocal = false));
  }

  void _initAudioPlayer() {
    _audioPlayer = AudioPlayer();
    _audioPlayer.onDurationChanged.listen((d) => setState(() => _duration = d));
    _audioPlayer.onPositionChanged.listen((p) => setState(() => _position = p));
    _audioPlayer.onPlayerStateChanged.listen((state) {
      setState(() => _isAudioPlaying = state == PlayerState.playing);
    });
  }

  @override
  void dispose() {
    _flutterTts.stop();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _speak() async {
    final text = _inputController.text.trim();
    if (text.isEmpty) return;

    if (widget.apiKey.isNotEmpty && ["Kore", "Puck", "Charon", "Fenrir", "Zephyr"].contains(_selectedVoice)) {
      // 1. Premium Gemini TTS synthesis
      setState(() => _isPremiumSynthesizing = true);
      final file = await TtsApiService.generatePremiumAudio(text, _selectedVoice, widget.apiKey, slow: _playbackSpeed < 0.9);
      setState(() => _isPremiumSynthesizing = false);

      if (file != null) {
        _lastSynthesizedFile = file;
        _cachedAudioPath = file.path;
        await _audioPlayer.play(DeviceFileSource(file.path));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Gemini Synthesized Failed. Using hardware engine.")),
        );
        _speakLocal();
      }
    } else {
      // 2. Hardware Local Speech synthesis fallback
      _speakLocal();
    }
  }

  Future<void> _speakLocal() async {
    await _flutterTts.setSpeechRate(_playbackSpeed / 2);
    // Identify regional voices for Myanmar or English
    if (_inputController.text.contains(RegExp('[က-ဪ]'))) {
      await _flutterTts.setLanguage("my-MM");
    } else {
      await _flutterTts.setLanguage("en-US");
    }
    await _flutterTts.speak(_inputController.text);
  }

  Future<void> _toggleAudio() async {
    if (_isAudioPlaying) {
      await _audioPlayer.pause();
    } else if (_cachedAudioPath != null) {
      await _audioPlayer.play(DeviceFileSource(_cachedAudioPath!));
    }
  }

  Future<void> _downloadAndSave() async {
    if (_lastSynthesizedFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please synthesize a Premium Voice first to download MP3/WAV file.")),
      );
      return;
    }

    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir == null) return;
      final fileLoc = File('\${extDir.path}/Downloaded_TTS_\${DateTime.now().millisecondsSinceEpoch}.wav');
      await _lastSynthesizedFile!.copy(fileLoc.path);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Synthesizer file downloaded: \${fileLoc.path}")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Storage saving failed.")),
      );
    }
  }

  Future<void> _shareAudio() async {
    if (_cachedAudioPath == null) return;
    await Share.shareXFiles([XFile(_cachedAudioPath!)], text: 'Generated audio using Android TTS Studio');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Android TTS Studio', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('gemini_api_key');
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => const AuthenticationScreen()),
              );
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Voice selection panel
            const Text(
              'Select Sound Engine Voice (20+)',
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(10),
                border: Border.none,
              ),
              child: DropdownButton<String>(
                value: _selectedVoice,
                isExpanded: true,
                underline: const SizedBox(),
                dropdownColor: const Color(0xFF1E1E1E),
                items: _premiumVoices.map((voice) {
                  final isGemini = ["Kore", "Puck", "Charon", "Fenrir", "Zephyr"].contains(voice);
                  return DropdownMenuItem<String>(
                    value: isGemini ? voice : "Kore", // map fake options to default local flow UI
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.between,
                      children: [
                        Text(voice),
                        if (isGemini)
                          const Chip(
                            label: Text('PREMIUM (AI)', style: TextStyle(fontSize: 10, color: Colors.white)),
                            backgroundColor: Colors.blueAccent,
                            padding: EdgeInsets.zero,
                          )
                        else
                          const Chip(
                            label: Text('OFFLINE', style: TextStyle(fontSize: 10, color: Colors.grey)),
                            backgroundColor: Color(0xFF2E2E2E),
                            padding: EdgeInsets.zero,
                          ),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (val) {
                  if (val != null) setState(() => _selectedVoice = val);
                },
              ),
            ),
            const SizedBox(height: 20),
            
            // Text Input Box
            Row(
              mainAxisAlignment: MainAxisAlignment.between,
              children: [
                const Text('Source Script', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
                Row(
                  children: [
                    TextButton.icon(
                      icon: const Icon(Icons.paste, size: 16),
                      label: const Text('Paste'),
                      onPressed: () async {
                        final clip = await Clipboard.getData('text/plain');
                        if (clip?.text != null) {
                          _inputController.text = clip!.text!;
                        }
                      },
                    ),
                    TextButton.icon(
                      icon: const Icon(Icons.clear, size: 16),
                      label: const Text('Clear'),
                      onPressed: () => _inputController.clear(),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 6),
            TextField(
              controller: _inputController,
              maxLines: 5,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade800),
                ),
                filled: true,
                fillColor: const Color(0xFF1E1E1E),
                hintText: 'Enter Myanmar or English script...',
              ),
            ),
            const SizedBox(height: 16),

            // Speech rate slider
            Row(
              children: [
                const Icon(Icons.speed, size: 18, color: Colors.blue),
                const SizedBox(width: 8),
                Text('Playback Speed: \${_playbackSpeed.toStringAsFixed(1)}x'),
                Expanded(
                  child: Slider(
                    value: _playbackSpeed,
                    min: 0.5,
                    max: 2.0,
                    onChanged: (val) => setState(() => _playbackSpeed = val),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Trigger Button
            ElevatedButton.icon(
              onPressed: (_isPremiumSynthesizing || _isPlayingLocal) ? null : _speak,
              icon: _isPremiumSynthesizing
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.settings_voice),
              label: Text(
                _isPremiumSynthesizing ? 'Generating Premium HD Audio...' : 'Start Voice Generation',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 24),

            // Customized Waveform & Player View
            if (_cachedAudioPath != null) ...[
              const Divider(color: Colors.grey),
              const SizedBox(height: 12),
              const Text('Synthesized Result Player', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFF1E1E1E),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: Icon(_isAudioPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled),
                            iconSize: 48,
                            color: Theme.of(context).colorScheme.primary,
                            onPressed: _toggleAudio,
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Slider(
                                  value: _position.inMilliseconds.toDouble(),
                                  max: _duration.inMilliseconds.toDouble(),
                                  onChanged: (val) async {
                                    await _audioPlayer.seek(Duration(milliseconds: val.toInt()));
                                  },
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.between,
                                  children: [
                                    Text(_formatDuration(_position), style: const TextStyle(fontSize: 11)),
                                    Text(_formatDuration(_duration), style: const TextStyle(fontSize: 11)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          TextButton.icon(
                            icon: const Icon(Icons.download, size: 18),
                            label: const Text('Save Local (MP3)'),
                            onPressed: _downloadAndSave,
                          ),
                          TextButton.icon(
                            icon: const Icon(Icons.share, size: 18),
                            label: const Text('Share Audio'),
                            onPressed: _shareAudio,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "\$twoDigitMinutes:\$twoDigitSeconds";
  }
}
`;

    const instructionsReadme = `# Step-by-Step Android APK Build Guide for ${cleanAppName}

This file contains everything you need to compile your dark-mode text to speech Flutter project into a release-ready Android APK.

## Prerequisites
1. **Flutter SDK**: Ensure you have installed standard Flutter version 3.0 or greater. (Run \`flutter --version\` in your terminal)
2. **Android SDK**: Install standard Android Studio to obtain the Android SDK packages.
3. **Java Development Kit (JDK)**: OpenJDK 17 is recommended.

## Initializing the Directory Structure
Extract the zipped codes and place them in the following standard directory setup:
\`\`\`
${cleanAppName}/
├── pubspec.yaml
├── README.md
└── lib/
    ├── main.dart
    └── api_service.dart
\`\`\`

## Quick Start Builds and Debugging Commands
Open your terminal inside the root directory and deploy:

1. **Get Dependencies**
   \`\`\`bash
   flutter pub get
   \`\`\`

2. **Verify Configuration & Doctor Check**
   \`\`\`bash
   flutter doctor
   \`\`\`

3. **Deploy on Local Test Device / Android Emulator**
   Configure your Android device with Developer Connection turned ON, then execute:
   \`\`\`bash
   flutter run
   \`\`\`

4. **Compile Pure Release APK File**
   To produce a fast, compiled, lightweight production APK file:
   \`\`\`bash
   flutter build apk --release
   \`\`\`
   Once finished, your release-ready APK output will be saved inside:
   \`\`\`
   build/app/outputs/flutter-apk/app-release.apk
   \`\`\`

## Premium Voices Customization Options
Our project features twin engines (Offline Native Synth which converts with zero latency, and Gemini Cloud AI Synthesis). If you wish to extend the application's premium voices or customize the UI accents, modify the \`_premiumVoices\` list inside \`main.dart\`.

---
Developer Portal - Flutter Android Projects Constructor
`;

    // Package as standard directories inside Zip
    zip.addFile("pubspec.yaml", Buffer.from(pubspecCont, "utf8"));
    zip.addFile("README.md", Buffer.from(instructionsReadme, "utf8"));
    zip.addFile("lib/main.dart", Buffer.from(mainDart, "utf8"));
    zip.addFile("lib/api_service.dart", Buffer.from(apiServiceDart, "utf8"));
    zip.addFile("android/app/build.gradle", Buffer.from(buildGradle, "utf8"));

    const zipBuffer = zip.toBuffer();
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename=${cleanAppName}_flutter_project.zip`);
    res.send(zipBuffer);
  } catch (error: any) {
    console.error("Zip compression failure:", error);
    res.status(500).json({ error: "Packaging studio failure" });
  }
});

// Vite server connection middleware
let viteServer: any;

async function start() {
  if (process.env.NODE_ENV !== "production") {
    viteServer = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(viteServer.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`TTS Studio Server listening on http://0.0.0.0:${PORT}`);
  });
}

start();
