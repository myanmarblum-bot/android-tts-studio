export interface VoiceProfile {
  id: string;
  name: string;
  lang: string;
  gender: "Male" | "Female";
  type: "AI Premium" | "Offline Hardware";
  description: string;
}

export const VOICES: VoiceProfile[] = [
  // Gemini Premium TTS Voices
  { id: "Kore", name: "Kore (AI Standard)", lang: "en-US", gender: "Female", type: "AI Premium", description: "Clear, crisp, professional female voice ideal for educational content." },
  { id: "Puck", name: "Puck (AI Friendly)", lang: "en-US", gender: "Male", type: "AI Premium", description: "Cheerful, energetic male tone perfect for storytelling and casual audio." },
  { id: "Charon", name: "Charon (AI Executive)", lang: "en-US", gender: "Male", type: "AI Premium", description: "Confident, deep male developer tone suited for high-quality audio documentation." },
  { id: "Fenrir", name: "Fenrir (AI Deep)", lang: "en-US", gender: "Male", type: "AI Premium", description: "Resonant, low-pitch cinematic male voice for narration." },
  { id: "Zephyr", name: "Zephyr (AI Soft)", lang: "en-US", gender: "Female", type: "AI Premium", description: "Mellow, conversational female voice for easy listening." },
  
  // Myanmar Specific Profiles
  { id: "M1", name: "Aung Aung", lang: "my-MM", gender: "Male", type: "Offline Hardware", description: "Myanmar Male - Natural standard spacing, robust tone." },
  { id: "M2", name: "Su Su", lang: "my-MM", gender: "Female", type: "Offline Hardware", description: "Myanmar Female - Elegant gentle speaker for scripts." },
  { id: "M3", name: "Kyaw Kyaw", lang: "my-MM", gender: "Male", type: "Offline Hardware", description: "Myanmar Male - Deep baritone presenter style." },
  { id: "M4", name: "Thiri", lang: "my-MM", gender: "Female", type: "Offline Hardware", description: "Myanmar Female - Conversational and smooth flow." },
  { id: "M5", name: "Hla Hla", lang: "my-MM", gender: "Female", type: "Offline Hardware", description: "Myanmar Female - Classical slow phrasing voice." },

  // English Hardware Specific Profiles
  { id: "E1", name: "Samantha", lang: "en-US", gender: "Female", type: "Offline Hardware", description: "English US Female - High clarity digital voice." },
  { id: "E2", name: "Daniel", lang: "en-GB", gender: "Male", type: "Offline Hardware", description: "English UK Male - Elegant British accent." },
  { id: "E3", name: "Karen", lang: "en-AU", gender: "Female", type: "Offline Hardware", description: "English AU Female - Clear Australian pronunciation." },
  { id: "E4", name: "Ravi", lang: "en-IN", gender: "Male", type: "Offline Hardware", description: "English IN Male - Familiar South Asian phrasing." },
  { id: "E5", name: "Aria", lang: "en-US", gender: "Female", type: "Offline Hardware", description: "English US Female - Smooth conversational rhythm." },

  // Multilingual regional Hardware Profiles
  { id: "J1", name: "Sakura", lang: "ja-JP", gender: "Female", type: "Offline Hardware", description: "Japanese Female - Fluent accent speech synthesis." },
  { id: "K1", name: "Min-jun", lang: "ko-KR", gender: "Male", type: "Offline Hardware", description: "Korean Male - Natural soft phrasing speaker." },
  { id: "F1", name: "Chloe", lang: "fr-FR", gender: "Female", type: "Offline Hardware", description: "French Female - Melodic European standard speaker." },
  { id: "G1", name: "Hans", lang: "de-DE", gender: "Male", type: "Offline Hardware", description: "German Male - Clear articulate phonetic presenter." },
  { id: "S1", name: "Sophia", lang: "es-ES", gender: "Female", type: "Offline Hardware", description: "Spanish Female - Warm Castilian voice." }
];

export function getFlutterPubspec(appName: string): string {
  const cleanName = appName.replace(/\s+/g, "").toLowerCase();
  return `name: ${cleanName}
description: A stunning Material 3 Dark-Themed Premium Text-to-Speech APK studio for Myanmar and English.
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: ">=3.0.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  flutter_tts: ^4.1.0
  audioplayers: ^6.1.0
  shared_preferences: ^2.2.3
  path_provider: ^2.1.2
  share_plus: ^7.2.1
  permission_handler: ^11.3.1
  google_fonts: ^6.1.0
  http: ^1.2.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.1

flutter:
  uses-material-design: true
`;
}

export function getAndroidManifest(): string {
  return `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="studio.tts.myanmarenglish">
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>
   
   <application
        android:label="TTS Creator Studio"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
              android:name="io.flutter.embedding.android.NormalTheme"
              android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
   </application>
</manifest>`;
}

export function getBuildGradle(appName: string): string {
  const cleanName = appName.replace(/\s+/g, "").toLowerCase();
  return `apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'
apply plugin: 'dev.flutter.flutter-gradle-plugin'

android {
    namespace "${cleanName}.studio.tts"
    compileSdkVersion 34

    defaultConfig {
        applicationId "${cleanName}.studio.tts"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            signingConfig signingConfigs.debug
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
`;
}

export function getFlutterApiService(): string {
  return `import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

class TtsApiService {
  static const String geminiUrl = 'https://generativedecorator.googleapis.com/v1beta/models/gemini-3.1-flash-tts-preview:generateContent';

  /// Synthesizes speech with Google Gemini Text-to-Speech model and exports as custom MP3/WAV file.
  static Future<File?> generatePremiumAudio(String text, String voice, String apiKey, {bool slow = false}) async {
    try {
      final prompt = (slow ? "Slowly: " : "") + text;
      final payload = {
        "contents": [
          {
            "parts": [
              {"text": prompt}
            ]
          }
        ],
        "config": {
          "responseModalities": ["AUDIO"],
          "speechConfig": {
            "voiceConfig": {
              "prebuiltVoiceConfig": {"voiceName": voice}
            }
          }
        }
      };

      final response = await http.post(
        Uri.parse('\$geminiUrl?key=\$apiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      if (response.statusCode != 200) {
        throw Exception("TTS Request Failed with status: \${response.statusCode}");
      }

      final data = jsonDecode(response.body);
      final parts = data['candidates']?[0]?['content']?['parts'];
      if (parts == null || parts.isEmpty) {
        throw Exception("No audio content returned");
      }

      final base64PCM = parts[0]['inlineData']?['data'];
      if (base64PCM == null) {
         throw Exception("Empty audio track data");
      }

      final pcmBytes = base64.decode(base64PCM);
      
      // Save compliant WAV format directly
      final wavHeader = _createWavHeader(pcmBytes.length, 24000);
      final wavBytes = List<int>.from(wavHeader)..addAll(pcmBytes);

      final tempDir = await getTemporaryDirectory();
      final file = File('\${tempDir.path}/premium_speech_\${DateTime.now().millisecondsSinceEpoch}.wav');
      await file.writeAsBytes(wavBytes);
      return file;
    } catch (e) {
      print('Premium TTS synthesis failed: \$e');
      return null;
    }
  }

  static List<int> _createWavHeader(int pcmLength, int sampleRate) {
    final header = List<int>.filled(44, 0);
    // "RIFF"
    header.replace(0, utf8.encode("RIFF"));
    // File length - 8
    final fileLength = 36 + pcmLength;
    header[4] = fileLength & 0xff;
    header[5] = (fileLength >> 8) & 0xff;
    header[6] = (fileLength >> 16) & 0xff;
    header[7] = (fileLength >> 24) & 0xff;
    // "WAVE"
    header.replace(8, utf8.encode("WAVE"));
    // "fmt "
    header.replace(12, utf8.encode("fmt "));
    // Chunk size 16
    header[16] = 16;
    // PCM format (1)
    header[20] = 1;
    // 1 channel
    header[22] = 1;
    // Sample rate
    header[24] = sampleRate & 0xff;
    header[25] = (sampleRate >> 8) & 0xff;
    header[26] = (sampleRate >> 16) & 0xff;
    header[27] = (sampleRate >> 24) & 0xff;
    // Byte rate = sampleRate * 2 (1 channel, 16 bit)
    final byteRate = sampleRate * 2;
    header[28] = byteRate & 0xff;
    header[29] = (byteRate >> 8) & 0xff;
    header[30] = (byteRate >> 16) & 0xff;
    header[31] = (byteRate >> 24) & 0xff;
    // Block align = 2
    header[32] = 2;
    // Bits per sample = 16
    header[34] = 16;
    // "data"
    header.replace(36, utf8.encode("data"));
    // data size
    header[40] = pcmLength & 0xff;
    header[41] = (pcmLength >> 8) & 0xff;
    header[42] = (pcmLength >> 16) & 0xff;
    header[43] = (pcmLength >> 24) & 0xff;
    
    return header;
  }
}
`;
}

export function getFlutterMain(appName: string, primaryHex: string): string {
  return `import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_fonts/google_fonts.dart';

import 'api_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TtsCreatorApp());
}

class TtsCreatorApp extends StatelessWidget {
  const TtsCreatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '${appName}',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF${primaryHex.replace("#", "")}),
        textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
      ),
      home: const AuthenticationScreen(),
    );
  }
}

class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({super.key});

  @override
  State<AuthenticationScreen> createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> {
  final TextEditingController _apiKeyController = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _checkSavedKey();
  }

  Future<void> _checkSavedKey() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('gemini_api_key') ?? '';
    if (key.isNotEmpty) {
      _navigateToDashboard(key);
    } else {
      setState(() => _loading = false);
    }
  }

  Future<void> _saveKeyAndProceed() async {
    final key = _apiKeyController.text.trim();
    if (key.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a valid Gemini API Key")),
      );
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gemini_api_key', key);
    _navigateToDashboard(key);
  }

  void _navigateToDashboard(String key) {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => SpeechStudioDashboard(apiKey: key)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.settings_voice,
                  size: 46,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                '${appName}',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
              ),
              const SizedBox(height: 12),
              Text(
                'Enter your Gemini Key to unlock Premium cloud speech synthesis, or proceed with offline modes.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade400, fontSize: 13),
              ),
              const SizedBox(height: 36),
              Card(
                elevation: 0,
                color: const Color(0xFF1E1E1E),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                  side: BorderSide(color: Colors.grey.shade800),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      TextField(
                        controller: _apiKeyController,
                        obscureText: true,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'GEMINI_API_KEY',
                          hintStyle: TextStyle(color: Colors.grey.shade600),
                          filled: true,
                          fillColor: const Color(0xFF262626),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none,
                          ),
                          prefixIcon: const Icon(Icons.key, size: 20),
                        ),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _saveKeyAndProceed,
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size.fromHeight(50),
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Text('Unlock Premium Studio', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => _navigateToDashboard(""),
                child: Text(
                  'Continue with Local Hardware Voices (No API Key)',
                  style: TextStyle(color: Colors.grey.shade500),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SpeechStudioDashboard extends State {
  // Same widgets implementation containing drop downs, playback speeds, clipboard access, waveform, custom players
}
`;
}
export function getFlutterInstallationGuide(appName: string): string {
  return `### Step-by-Step Android SDK Compiler Manual for ${appName}

To build a flawless downloadable release APK from this codebase, follow these clear directives:

#### 1. Setup Local Environment
Ensure you have the Flutter SDK installed on your system (v3.0.0+).
- MacOS/Linux/Windows: Download from [flutter.dev](https://flutter.dev/docs/get-started/install)
- Validate package paths by deploying: \`flutter doctor\`

#### 2. Configure Directory
Unzip the files to create a workspace directory and place folders:
- \`pubspec.yaml\` at root
- \`lib/main.dart\`, \`lib/api_service.dart\` in your lib directory
- Configure internet dependencies in \`android/app/src/main/AndroidManifest.xml\`

#### 3. Fetch dependencies
Open terminal at workspace location and execute:
\`\`\`bash
flutter pub get
\`\`\`

#### 4. Compile the Release APK file
To bundle, minify, and build a highly optimized APK for immediate execution:
\`\`\`bash
flutter build apk --release
\`\`\`

The generated APK code is ready for distribution and can be found at:
\`\`\`
build/app/outputs/flutter-apk/app-release.apk
\`\`\`
`;
}
