import React, { useState, useEffect, useRef } from "react";
import { 
  Play, Pause, Download, Copy, Check, Settings, Code, Cpu, 
  Volume2, BookOpen, Trash2, Key, Sliders, Folder, Terminal, 
  ArrowRight, ShieldCheck, CheckCircle2, ChevronDown, RefreshCw, 
  Sparkles, FileText, Smartphone, RefreshCcw, Info, Clipboard, AlertCircle
} from "lucide-react";
import { 
  VOICES, getFlutterPubspec, getBuildGradle, 
  getFlutterApiService, getFlutterMain, getFlutterInstallationGuide, VoiceProfile 
} from "./templates";

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<"studio" | "code" | "builder">("studio");
  
  // Custom Flutter Project export properties
  const [appName, setAppName] = useState("Aung Myanmar TTS");
  const [primaryColor, setPrimaryColor] = useState("#2563eb");
  const [primaryColorName, setPrimaryColorName] = useState("Material Blue");

  // User details & credentials
  const [apiKey, setApiKey] = useState(() => {
    return localStorage.getItem("user_gemini_api_key") || "";
  });
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  // Active Synthesis states
  const [text, setText] = useState(
    "မင်္ဂလာပါ၊ မြန်မာ English Text To Speech Studio မှ ကြိုဆိုပါသည်။ Welcome to high performance audio synthesis. \n\nSelect any Premium AI voice to experience realistic human speech, or export this complete Flutter project to compile a native Android APK immediately."
  );
  const [selectedVoice, setSelectedVoice] = useState<VoiceProfile>(VOICES[0]);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Player state
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Clipboard animations
  const [copiedText, setCopiedText] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Code inspection selection
  const [selectedFile, setSelectedFile] = useState<"pubspec" | "main" | "api" | "gradle" | "readme">("main");

  // Active dancing sound waves frequency array
  const [waveHeights, setWaveHeights] = useState<number[]>(new Array(18).fill(8));
  const animationRef = useRef<number | null>(null);

  // Synchronize localStorage
  const handleSaveApiKey = (key: string) => {
    const trimmed = key.trim();
    setApiKey(trimmed);
    localStorage.setItem("user_gemini_api_key", trimmed);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
    setShowApiKeyInput(false);
  };

  const handleClearApiKey = () => {
    setApiKey("");
    localStorage.removeItem("user_gemini_api_key");
  };

  // Soundwave animation generator
  useEffect(() => {
    if (isPlaying) {
      const updateWave = () => {
        setWaveHeights(prev => prev.map(() => Math.floor(Math.random() * 32) + 6));
        animationRef.current = requestAnimationFrame(updateWave);
      };
      animationRef.current = requestAnimationFrame(updateWave);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      setWaveHeights(new Array(18).fill(6));
    }
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isPlaying]);

  // Audio Playback progress tracker
  useEffect(() => {
    if (!audioUrl) return;
    const audio = new Audio(audioUrl);
    audioRef.current = audio;

    const handleLoadedMetadata = () => {
      setDuration(audio.duration || 10);
    };

    const handleTimeUpdate = () => {
      setProgress(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
    };

    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("ended", handleEnded);

    // Apply playback speed
    audio.playbackRate = playbackSpeed;

    return () => {
      audio.pause();
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("ended", handleEnded);
      audioRef.current = null;
    };
  }, [audioUrl]);

  // Dynamically update speed as it slides
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Handle Play/Pause
  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(err => {
          console.error("Playback failed:", err);
          setIsPlaying(false);
        });
    }
  };

  // Perform Speach Synthesis via server or offline browser
  const handleGenerateSpeech = async () => {
    setErrorMessage(null);
    setIsPlaying(false);

    if (!text.trim()) {
      setErrorMessage("Please enter text content to synthesize.");
      return;
    }

    // 1. Premium AI Voice Flow via server proxy
    if (selectedVoice.type === "AI Premium") {
      setIsSynthesizing(true);
      try {
        const response = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text: text,
            voice: selectedVoice.id,
            apiKey: apiKey || undefined, // empty uses server configured key automatically!
            rate: playbackSpeed < 0.9 ? "slow" : "normal"
          })
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData.error || `Synthesis failed (Code ${response.status})`);
        }

        const audioBlob = await response.blob();
        if (audioBlob.size < 100) {
          throw new Error("Returned audio data is empty. Please verify your script.");
        }

        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);

        // Auto play on success
        setTimeout(() => {
          if (audioRef.current) {
            audioRef.current.play()
              .then(() => setIsPlaying(true))
              .catch(() => {});
          }
        }, 150);

      } catch (err: any) {
        console.error("Gemini premium tts error:", err);
        setErrorMessage(err.message || "Failed to reach premium cloud synthesizer. Please fallback to local hardware voices.");
      } finally {
        setIsSynthesizing(false);
      }
    } else {
      // 2. Local Hardware Voice Speech synthesis
      setIsSynthesizing(true);
      try {
        const synth = window.speechSynthesis;
        if (!synth) {
          throw new Error("Local Web Speech Synthesis is not supported in this browser version.");
        }

        // Cancel any pending speech
        synth.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        
        // Find best match matching browser voice list
        const voices = synth.getVoices();
        const matchingLocale = voices.find(v => v.lang.startsWith(selectedVoice.lang));
        if (matchingLocale) {
          utterance.voice = matchingLocale;
        }
        
        utterance.rate = playbackSpeed;
        
        utterance.onstart = () => {
          setIsSynthesizing(false);
          setIsPlaying(true);
          // Standard browser offline synthesis duration approximation
          setDuration(text.length * 0.08); 
          setProgress(0);
        };

        utterance.onend = () => {
          setIsPlaying(false);
          setProgress(0);
        };

        utterance.onerror = (e) => {
          throw new Error(`Speech synthesis process failed: ${e.error}`);
        };

        synth.speak(utterance);

        // Dynamic local timeline emulation
        const interval = setInterval(() => {
          if (synth.speaking && !synth.paused) {
            setProgress(prev => {
              if (prev >= text.length * 0.08) {
                clearInterval(interval);
                return prev;
              }
              return prev + 0.1;
            });
          } else {
            clearInterval(interval);
          }
        }, 100);

      } catch (err: any) {
        setIsSynthesizing(false);
        setErrorMessage(err.message || "Local speech synthesis failed.");
      }
    }
  };

  // ZIP compiler request
  const handleDownloadZip = async () => {
    try {
      const response = await fetch("/api/export-zip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          appName: appName,
          primaryColor: primaryColor.replace("#", "0xFF"),
          selectedLanguage: selectedVoice.lang
        })
      });

      if (!response.ok) {
        throw new Error("Packaging export ZIP failed on server");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${appName.replace(/\s+/g, "")}_flutter_project.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err: any) {
      alert("Failed to export full Flutter zip portfolio. Details: " + err.message);
    }
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const handlePasteText = async () => {
    try {
      const clipText = await navigator.clipboard.readText();
      if (clipText) {
        setText(prev => prev + (prev ? "\n" : "") + clipText);
      }
    } catch (err) {
      alert("Please grant clipboard permission to paste directly.");
    }
  };

  const handleCopyCode = (codeText: string, fileId: string) => {
    navigator.clipboard.writeText(codeText);
    setCopiedCode(fileId);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const formatTime = (timeInSecs: number) => {
    const mins = Math.floor(timeInSecs / 60);
    const secs = Math.floor(timeInSecs % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  // Quick text inputs templates
  const injectBurmeseSample = () => {
    setText("မြန်မာနိုင်ငံတော်၏ သာယာလှပသော နံနက်ခင်းတွင် အားလုံးပဲ မင်္ဂလာပါ။ စာသားမှ အသံထွက်စနစ်သည် ကောင်းမွန်စွာ အလုပ်လုပ်နေပါသည်။");
  };

  const injectEnglishSample = () => {
    setText("The quick brown fox jumps over the lazy dog. Realistic cloud text-to-speech engine is currently active with high-fidelity modulation.");
  };

  // Code visualizer templates selector
  const getSelectedCodeText = () => {
    switch (selectedFile) {
      case "pubspec": return getFlutterPubspec(appName);
      case "main": return getFlutterMain(appName, primaryColor);
      case "api": return getFlutterApiService();
      case "gradle": return getBuildGradle(appName);
      case "readme": return getFlutterInstallationGuide(appName);
    }
  };

  const getSelectedCodeHeader = () => {
    switch (selectedFile) {
      case "pubspec": return "pubspec.yaml";
      case "main": return "lib/main.dart";
      case "api": return "lib/api_service.dart";
      case "gradle": return "android/app/build.gradle";
      case "readme": return "README.md (Build Guide)";
    }
  };

  return (
    <div className="min-h-screen bg-[#141218] text-[#E6E1E5] flex flex-col font-sans transition-all selection:bg-[#4F378B]/40">
      
      {/* Premium Header */}
      <header className="border-b border-[#49454F] bg-[#1D1B20] sticky top-0 z-40 px-6 py-4 flex flex-wrap gap-4 justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#4F378B] flex items-center justify-center shadow-lg shadow-[#381E72]/30 border border-[#D0BCFF]/20">
            <Volume2 className="w-6 h-6 text-[#D0BCFF] animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Android TTS <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-[#381E72] text-[#D0BCFF] border border-[#D0BCFF]/20">STUDIO PRO</span>
            </h1>
            <p className="text-xs text-[#938F99] hidden sm:block">Professional Myanmar & English Audioworks Synthesizer</p>
          </div>
        </div>

        {/* Global Nav Menu */}
        <div className="flex bg-[#2B2930] rounded-2xl p-1 border border-[#49454F]">
          <button 
            id="tab-studio"
            onClick={() => setActiveTab("studio")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer ${
              activeTab === "studio" 
                ? "bg-[#4F378B] text-white shadow-md shadow-[#381E72]/50" 
                : "text-[#CAC4D0] hover:text-[#E6E1E5]"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Audio Studio</span>
          </button>
          
          <button 
            id="tab-code"
            onClick={() => setActiveTab("code")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer ${
              activeTab === "code" 
                ? "bg-[#4F378B] text-white shadow-md shadow-[#381E72]/50" 
                : "text-[#CAC4D0] hover:text-[#E6E1E5]"
            }`}
          >
            <Code className="w-4 h-4" />
            <span>Flutter Source</span>
          </button>
          
          <button 
            id="tab-builder"
            onClick={() => setActiveTab("builder")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer ${
              activeTab === "builder" 
                ? "bg-[#4F378B] text-white shadow-md shadow-[#381E72]/50" 
                : "text-[#CAC4D0] hover:text-[#E6E1E5]"
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>APK Compiler</span>
          </button>
        </div>

        {/* API Key management */}
        <div className="flex items-center gap-2">
          {apiKey ? (
            <div className="hidden md:flex items-center gap-2 bg-[#381E72]/30 border border-[#D0BCFF]/30 text-[#D0BCFF] text-xs px-3 py-1.5 rounded-xl">
              <ShieldCheck className="w-4 h-4" />
              <span>Gemini AI Unlocked</span>
              <button 
                id="btn-clear-key"
                onClick={handleClearApiKey}
                className="text-[#D0BCFF]/80 hover:text-rose-400 ml-1 font-semibold underline cursor-pointer"
              >
                Clear Key
              </button>
            </div>
          ) : (
            <button 
              id="btn-show-key-input"
              onClick={() => setShowApiKeyInput(!showApiKeyInput)}
              className="flex items-center gap-2 bg-[#2B2930] hover:bg-[#4F378B]/20 border border-[#49454F] text-[#CAC4D0] hover:text-[#E6E1E5] text-xs px-4 py-2 rounded-xl transition cursor-pointer"
            >
              <Key className="w-3.5 h-3.5 text-[#D0BCFF]" />
              <span>Custom API Key</span>
            </button>
          )}

          {/* Secure Cloud indicator */}
          <div className="flex items-center gap-1.5 bg-[#381E72]/30 border border-[#D0BCFF]/15 text-[#D0BCFF] text-xs px-3 py-1.5 rounded-xl">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D0BCFF] animate-ping"></span>
            <span>Cloud Active</span>
          </div>
        </div>
      </header>

      {/* Cloud API Key Set Popup Drawer */}
      {showApiKeyInput && (
        <div className="bg-[#1D1B20] border-b border-[#49454F] px-6 py-4 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#381E72] text-[#D0BCFF] flex items-center justify-center shrink-0 mt-1 border border-[#D0BCFF]/20">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <p className="text-sm font-semibold text-[#E6E1E5]">Enter Custom Google Gemini API Key</p>
              <p className="text-xs text-[#938F99]">
                Premium synthetic voices require authorization. In this sandbox preview, your backend utilizes standard environment keys automatically. Include keys when building your native APK.
              </p>
            </div>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <input 
              id="input-api-key"
              type="password" 
              placeholder="AIzaSy..." 
              defaultValue={apiKey}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSaveApiKey((e.target as HTMLInputElement).value);
                }
              }}
              className="bg-[#141218] border border-[#49454F] rounded-xl px-4 py-2 text-sm text-[#E6E1E5] focus:outline-none focus:border-[#D0BCFF] focus:ring-1 focus:ring-[#D0BCFF] w-full md:w-64"
            />
            <button 
              id="btn-save-key"
              onClick={() => {
                const inputVal = (document.getElementById("input-api-key") as HTMLInputElement)?.value;
                handleSaveApiKey(inputVal || "");
              }}
              className="bg-[#D0BCFF] text-[#381E72] hover:bg-[#E8DEF8] text-sm px-4 py-2 rounded-xl font-bold shrink-0 cursor-pointer"
            >
              Save Key
            </button>
          </div>
        </div>
      )}

      {/* Main Workspace Frame */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-6 flex flex-col gap-6">

        {/* Tab 1: Studio */}
        {activeTab === "studio" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Control Column Left (7 columns) */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              
              {/* Text Input Block */}
              <div className="bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl shadow-black/10">
                <div className="flex items-center justify-between border-b border-[#49454F] pb-4 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="p-1 px-2.5 text-[11px] font-semibold rounded-full bg-[#381E72] text-[#D0BCFF] border border-[#D0BCFF]/20">Myanmar/English</span>
                    <h3 className="text-sm font-bold text-white">Synthesis Script Editor</h3>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      id="btn-sample-myanmar"
                      onClick={injectBurmeseSample}
                      className="text-xs text-[#CAC4D0] hover:text-[#E6E1E5] px-3 py-1.5 bg-[#2B2930] hover:bg-[#4F378B]/20 rounded-xl border border-[#49454F] transition cursor-pointer"
                    >
                      Burmese Sample
                    </button>
                    <button 
                      id="btn-sample-english"
                      onClick={injectEnglishSample}
                      className="text-xs text-[#CAC4D0] hover:text-[#E6E1E5] px-3 py-1.5 bg-[#2B2930] hover:bg-[#4F378B]/20 rounded-xl border border-[#49454F] transition cursor-pointer"
                    >
                      English Sample
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <textarea 
                    id="input-tts-text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Enter sentences, lyrics or scripts here in Myanmar or English for AI vocals synthesis..."
                    rows={7}
                    maxLength={1500}
                    className="w-full bg-[#141218] text-[#E6E1E5] placeholder-[#49454F] text-sm p-4 rounded-xl focus:outline-none focus:ring-1 focus:ring-[#D0BCFF] focus:border-[#D0BCFF] border border-[#49454F] resize-none leading-relaxed transition"
                  />
                  
                  {/* Floating count */}
                  <span className="absolute bottom-3 right-3 text-[10px] text-[#938F99] font-mono">
                    {text.length}/1500 chars
                  </span>
                </div>

                {/* Editor utilities bar */}
                <div className="flex justify-between items-center mt-3 pt-3 border-t border-[#49454F]">
                  <div className="flex gap-1">
                    <button 
                      id="btn-paste-clipboard"
                      onClick={handlePasteText}
                      className="flex items-center gap-1.5 text-xs text-[#D0BCFF] hover:text-[#E8DEF8] px-3 py-1.5 rounded-lg hover:bg-[#4F378B]/10 transition cursor-pointer"
                      title="Paste from clipboard"
                    >
                      <Clipboard className="w-3.5 h-3.5 text-[#D0BCFF]" />
                      <span>Paste</span>
                    </button>
                    <button 
                      id="btn-clear-textbox"
                      onClick={() => setText("")}
                      className="flex items-center gap-1.5 text-xs text-rose-400/90 hover:text-rose-300 px-3 py-1.5 rounded-xl hover:bg-rose-500/10 transition cursor-pointer"
                      title="Clear textarea"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1 text-[11px] text-[#CAC4D0]/95 bg-[#381E72]/20 px-3 py-1.5 rounded-xl border border-[#D0BCFF]/10">
                    <Info className="w-3 h-3 text-[#D0BCFF]" />
                    <span>Copying output audio preserves full stereo WAV container</span>
                  </div>
                </div>
              </div>

              {/* Advanced Parameters Controller */}
              <div className="bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl">
                <div className="flex items-center gap-2 border-b border-[#49454F] pb-4 mb-4">
                  <Sliders className="w-4 h-4 text-[#D0BCFF]" />
                  <h3 className="text-sm font-bold text-white">Synthesize Tuning Matrix</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  
                  {/* Speed controller */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-[#CAC4D0]">Voice Tempo (Speed)</span>
                      <span className="text-xs font-mono font-bold text-[#D0BCFF] bg-[#381E72] px-2 py-0.5 rounded-md border border-[#D0BCFF]/10">
                        {playbackSpeed === 1.0 ? "Normal (1.0x)" : `${playbackSpeed.toFixed(1)}x`}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 bg-[#141218] p-3 rounded-xl border border-[#49454F]">
                      <span className="text-xs text-[#938F99] shrink-0">0.5x</span>
                      <input 
                        id="slider-playback-speed"
                        type="range" 
                        min="0.5" 
                        max="2.0" 
                        step="0.1" 
                        value={playbackSpeed}
                        onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                        className="w-full accent-[#D0BCFF] h-1 rounded-lg cursor-pointer"
                      />
                      <span className="text-xs text-[#938F99] shrink-0">2.0x</span>
                    </div>
                  </div>

                  {/* Engine Details info card */}
                  <div className="flex flex-col gap-2">
                    <span className="text-xs font-semibold text-[#CAC4D0]">Rendering Engine Node</span>
                    <div className="bg-[#141218] p-3.5 rounded-2xl border border-[#49454F] flex-1 flex items-center justify-between">
                      {selectedVoice.type === "AI Premium" ? (
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-[#381E72] text-[#D0BCFF] flex items-center justify-center shrink-0 border border-[#D0BCFF]/10">
                            <Sparkles className="w-4.5 h-4.5" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-[#E6E1E5]">Gemini 3.1 Cloud Synthesis</p>
                            <p className="text-[10px] text-[#938F99]">Direct neural multi-lingual PCM model</p>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-[#2B2930] text-[#938F99] flex items-center justify-center shrink-0 border border-[#49454F]">
                            <Cpu className="w-4.5 h-4.5" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-[#E6E1E5]">Device Hardware Framework</p>
                            <p className="text-[10px] text-[#938F99]">On-device local speech synthesis</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                </div>
              </div>

            </div>

            {/* Selector and Player Right (5 columns) */}
            <div className="lg:col-span-5 flex flex-col gap-6">

              {/* 20+ Voices Selector */}
              <div className="bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl">
                <div className="flex justify-between items-center border-b border-[#49454F] pb-4 mb-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    Voice Sound Engine Selector
                  </h3>
                  <span className="text-[10.5px] font-bold text-[#D0BCFF] bg-[#381E72] px-2.5 py-0.5 rounded-full border border-[#D0BCFF]/20 font-mono">
                    20+ Voices Available
                  </span>
                </div>

                <div className="max-h-[220px] overflow-y-auto pr-1 flex flex-col gap-2 scrollbar-thin scrollbar-thumb-gray-800">
                  {VOICES.map((voice) => {
                    const isSelected = selectedVoice.id === voice.id;
                    const isCloud = voice.type === "AI Premium";

                    return (
                      <button
                        key={voice.id}
                        id={`voice-btn-${voice.id}`}
                        onClick={() => {
                          setSelectedVoice(voice);
                          // Reset player URL on voice switch to prevent context mixups
                          setAudioUrl(null);
                        }}
                        className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition cursor-pointer ${
                          isSelected 
                            ? "bg-[#4F378B]/20 border-[#D0BCFF]/40 text-white shadow-sm shadow-[#381E72]/15" 
                            : "bg-[#2B2930] border-transparent text-[#CAC4D0] hover:border-[#49454F] hover:bg-[#2B2930]/85"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-mono font-bold ${
                            isSelected 
                              ? "bg-[#D0BCFF] text-[#381E72]" 
                              : isCloud ? "bg-[#381E72] text-[#D0BCFF] border border-[#D0BCFF]/15" : "bg-[#141218] text-[#938F99] border border-[#49454F]"
                          }`}>
                            {voice.gender === "Male" ? "M" : "F"}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white flex items-center gap-1.5">
                              {voice.name}
                              <span className="text-[10px] bg-[#141218] font-semibold text-[#CAC4D0] px-1.5 py-0.2 rounded border border-[#49454F]/30 font-mono uppercase">
                                {voice.lang}
                              </span>
                            </p>
                            <p className="text-[10px] text-[#938F99] line-clamp-1">{voice.description}</p>
                          </div>
                        </div>

                        {/* Tag details */}
                        <div>
                          {isCloud ? (
                            <span className="text-[9px] bg-[#381E72] text-[#D0BCFF] font-bold px-1.5 py-0.5 rounded-full border border-[#D0BCFF]/20 uppercase">
                              AI Premium
                            </span>
                          ) : (
                            <span className="text-[9px] bg-[#141218] text-[#938F99] font-bold px-1.5 py-0.5 rounded-full border border-[#49454F] uppercase">
                              Offline
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Synthesis trigger check */}
                <div className="mt-5">
                  <button
                    id="btn-trigger-synthesis"
                    onClick={handleGenerateSpeech}
                    disabled={isSynthesizing}
                    className={`w-full flex items-center justify-center gap-2.5 py-4 px-6 rounded-xl font-bold transition shadow-lg shrink-0 cursor-pointer ${
                      isSynthesizing 
                        ? "bg-[#2B2930] text-[#938F99] border border-[#49454F] cursor-not-allowed" 
                        : "bg-[#D0BCFF] text-[#381E72] hover:bg-[#E8DEF8] shadow-lg shadow-[#381E72]/20 font-semibold"
                    }`}
                  >
                    {isSynthesizing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-[#D0BCFF]" />
                        <span>Synthesizing Voice Fields...</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-5 h-5 animate-bounce" />
                        <span className="text-sm">Synthesize Text to Speech</span>
                      </>
                    )}
                  </button>
                  
                  {errorMessage && (
                    <div className="mt-3 p-3 rounded-xl bg-[#BA1A1A]/10 border border-[#BA1A1A]/30 text-[#FFB4AB] text-xs flex gap-2 items-start">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{errorMessage}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Dynamic Sound Wave & Performance Audio Player */}
              <div className="bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white">Studio Audio Deck</h3>

                {/* Animated sound equalizer */}
                <div className="bg-[#2B2930] border border-[#49454F] rounded-2xl p-6 flex flex-col justify-center items-center gap-4 relative overflow-hidden min-h-[140px]">
                  
                  {/* Subtle decorative radial grid gradient */}
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(208,188,255,0.08),transparent)] pointer-events-none" />

                  {/* Dancing Waveform Visualizer */}
                  <div className="flex items-end gap-[3px] h-14 w-full justify-center">
                    {waveHeights.map((h, i) => (
                      <div 
                        key={i} 
                        style={{ height: `${h}px` }}
                        className={`w-1.5 rounded-full transition-all duration-100 ${
                          isPlaying 
                            ? "bg-gradient-to-t from-[#4F378B] to-[#D0BCFF] shadow-sm shadow-[#381E72]/35" 
                            : "bg-[#49454F]"
                        }`}
                      />
                    ))}
                  </div>

                  {/* File Metadata indicator */}
                  <div className="z-10 text-center">
                    <p className="text-xs font-bold text-white">
                      {isPlaying ? "Playing Synthesized Track" : isSynthesizing ? "Generating Signal Matrix..." : "Sequencer Idle"}
                    </p>
                    <p className="text-[10px] text-[#938F99] font-medium">
                      {selectedVoice.name} • {selectedVoice.type} • 24000 Hz Stereo
                    </p>
                  </div>
                </div>

                {/* Micro controller bar */}
                <div className="flex flex-col gap-3 bg-[#141218] border border-[#49454F] p-4 rounded-2xl">
                  
                  {/* Playhead slider timeline */}
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono text-[#938F99] w-10 shrink-0 text-right">
                      {formatTime(progress)}
                    </span>
                    <div className="flex-1 h-1.5 rounded-full bg-[#49454F] relative overflow-hidden">
                      <div 
                        style={{ width: `${duration > 0 ? (progress / duration) * 100 : 0}%` }}
                        className="absolute h-full inset-y-0 left-0 bg-[#D0BCFF] rounded-full"
                      />
                    </div>
                    <span className="text-[10px] font-mono text-[#938F99] w-10 shrink-0">
                      {formatTime(duration)}
                    </span>
                  </div>

                  {/* Buttons controller */}
                  <div className="flex justify-between items-center mt-2">
                    <button
                      id="btn-play-pause"
                      onClick={togglePlay}
                      disabled={!audioUrl && selectedVoice.type === "AI Premium"}
                      className={`p-3 rounded-full flex items-center justify-center transition cursor-pointer ${
                        isPlaying 
                          ? "bg-amber-600/10 text-amber-400 border border-amber-500/35 hover:bg-amber-600/20" 
                          : "bg-[#4F378B] hover:bg-[#5e41a6] text-white shadow-md shadow-[#381E72]/40"
                      } ${(!audioUrl && selectedVoice.type === "AI Premium") ? "opacity-30 cursor-not-allowed" : ""}`}
                    >
                      {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                    </button>

                    <div className="flex gap-2">
                      {/* Copy synthesized binary audio text */}
                      <button
                        id="btn-copy-script"
                        onClick={handleCopyText}
                        className="flex items-center gap-1.5 bg-[#2B2930] hover:bg-[#4F378B]/20 border border-[#49454F] text-[#CAC4D0] hover:text-[#E6E1E5] px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider font-mono transition cursor-pointer"
                      >
                        {copiedText ? (
                          <>
                            <Check className="w-4.5 h-4.5 text-emerald-400" />
                            <span>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-4.5 h-4.5" />
                            <span>Copy Script</span>
                          </>
                        )}
                      </button>

                      {/* Download generated WAV file */}
                      <a
                        id="btn-download-wav"
                        href={audioUrl || "#"}
                        download={`${selectedVoice.name.replace(/\s+/g, "")}_synthesis.wav`}
                        onClick={(e) => {
                          if (!audioUrl) {
                            e.preventDefault();
                            alert("Synthesize standard AI Premium voice contents first to download WAV audio file.");
                          }
                        }}
                        className={`flex items-center gap-1.5 bg-[#D0BCFF] text-[#381E72] hover:bg-[#E8DEF8] px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider font-mono transition shadow-md shadow-[#381E72]/20 cursor-pointer ${
                          !audioUrl ? "opacity-30 cursor-not-allowed" : ""
                        }`}
                      >
                        <Download className="w-4.5 h-4.5" />
                        <span>Download MP3</span>
                      </a>
                    </div>
                  </div>

                </div>

                {/* APK Export teaser card */}
                <div className="bg-[#2B2930]/50 border border-[#D0BCFF]/10 rounded-[20px] p-5 flex flex-col gap-2.5 text-[#CAC4D0]">
                  <div className="flex gap-2 items-center">
                    <Smartphone className="w-4 h-4 text-[#D0BCFF]" />
                    <span className="text-xs font-bold text-white">Flutter Android Compilation Port</span>
                  </div>
                  <p className="text-[11px] text-[#938F99] leading-relaxed">
                    Satisfied with the audio synthesizer? Click the <strong className="text-[#D0BCFF]">Flutter Source</strong> tab on header to configure colors, assign your app name, and download a complete zipped codebase ready for SDK compilation.
                  </p>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: Flutter Code Constructor */}
        {activeTab === "code" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Parameter matrix (4 columns) */}
            <div className="lg:col-span-4 bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl flex flex-col gap-6">
              
              <div>
                <h3 className="text-sm font-bold text-white mb-1.5 flex items-center gap-2">
                  <Settings className="w-4 h-4 text-[#D0BCFF]" />
                  <span>Customize Export Profile</span>
                </h3>
                <p className="text-[11.5px] text-[#938F99] leading-relaxed">
                  These settings will modify variables, bundle declarations, layout themes, and accent properties throughout the Flutter files.
                </p>
              </div>

              {/* Variable 1: APK App Title */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-[#CAC4D0]">App Launcher Name</label>
                <input 
                  id="config-app-name"
                  type="text" 
                  value={appName} 
                  onChange={(e) => setAppName(e.target.value)}
                  placeholder="e.g. Aung Myanmar TTS"
                  className="bg-[#141218] border border-[#49454F] text-[#E6E1E5] text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-[#D0BCFF] focus:ring-1 focus:ring-[#D0BCFF]"
                />
              </div>

              {/* Variable 2: Accent Palette Color */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold text-[#CAC4D0]">Material Accent Color</label>
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { color: "#2563eb", name: "Material Blue" },
                    { color: "#ea580c", name: "Cyber Orange" },
                    { color: "#16a34a", name: "Forest Green" },
                    { color: "#9333ea", name: "Imperial Purple" },
                    { color: "#db2777", name: "Classic Pink" }
                  ].map((preset) => {
                    const isSelected = primaryColor === preset.color;
                    return (
                      <button
                        key={preset.color}
                        title={preset.name}
                        onClick={() => {
                          setPrimaryColor(preset.color);
                          setPrimaryColorName(preset.name);
                        }}
                        style={{ backgroundColor: preset.color }}
                        className={`aspect-square rounded-lg border-2 transition transform hover:scale-105 cursor-pointer ${
                          isSelected ? "border-[#D0BCFF] scale-105 shadow-md shadow-[#D0BCFF]/10" : "border-transparent"
                        }`}
                      />
                    );
                  })}
                </div>
                <div className="text-[10px] text-[#938F99] flex justify-between items-center mt-1 bg-[#141218] border border-[#49454F] p-3 rounded-xl">
                  <span>Selected Accent: </span>
                  <span className="font-bold font-mono" style={{ color: primaryColor }}>{primaryColorName} ({primaryColor})</span>
                </div>
              </div>

              {/* Bundle identifier display card */}
              <div className="bg-[#2B2930] border border-[#49454F] p-4 rounded-2xl flex flex-col gap-2 text-xs text-[#CAC4D0]">
                <span className="font-bold text-white">Project Bundle ID:</span>
                <span className="font-mono text-[10px] bg-[#141218] px-3 py-1.5 rounded-xl text-[#D0BCFF] border border-[#49454F]/40">
                  {appName.toLowerCase().replace(/\s+/g, "")}.studio.tts
                </span>
                <span className="text-[10px] leading-relaxed text-[#938F99] mt-1">
                  Fully declared inside build profiles, build directories & compile assets.
                </span>
              </div>

              {/* Download Master ZIP Button */}
              <button
                id="btn-download-bundle-zip"
                onClick={handleDownloadZip}
                className="w-full bg-[#D0BCFF] text-[#381E72] hover:bg-[#E8DEF8] py-3.5 px-6 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2.5 transition shadow-lg shadow-[#381E72]/25 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Export Flutter ZIP File</span>
              </button>

            </div>

            {/* Right File Browser and Inspector (8 columns) */}
            <div className="lg:col-span-8 bg-[#1D1B20] border border-[#49454F] rounded-[28px] flex flex-col shadow-xl overflow-hidden">
              
              {/* Toolbar file selector tabs */}
              <div className="bg-[#2B2930] border-b border-[#49454F] px-4 py-3 flex flex-wrap gap-2">
                {[
                  { fileId: "pubspec", label: "pubspec.yaml", icon: FileText },
                  { fileId: "main", label: "lib/main.dart", icon: Code },
                  { fileId: "api", label: "lib/api_service.dart", icon: Sparkles },
                  { fileId: "gradle", label: "app/build.gradle", icon: Settings },
                  { fileId: "readme", label: "README.md", icon: BookOpen }
                ].map((item) => {
                  const isCur = selectedFile === item.fileId;
                  const IconComp = item.icon;
                  return (
                    <button
                      key={item.fileId}
                      id={`tab-file-btn-${item.fileId}`}
                      onClick={() => setSelectedFile(item.fileId as any)}
                      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-[11.5px] font-mono transition cursor-pointer ${
                        isCur 
                          ? "bg-[#4F378B]/20 text-[#D0BCFF] border border-[#D0BCFF]/30 font-bold" 
                          : "text-[#CAC4D0] hover:text-[#E6E1E5] hover:bg-[#141218]/45"
                      }`}
                    >
                      <IconComp className="w-3.5 h-3.5" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Interactive Code Frame Container */}
              <div className="flex-1 p-5 bg-[#141218] relative min-h-[460px] flex flex-col">
                
                {/* Code header bar */}
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[10px] font-mono text-[#938F99] flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D0BCFF]" />
                    <span>Project File: {getSelectedCodeHeader()}</span>
                  </span>
                  
                  <button
                    id="btn-copy-selected-code"
                    onClick={() => handleCopyCode(getSelectedCodeText(), selectedFile)}
                    className="flex items-center gap-1.5 bg-[#2B2930] hover:bg-[#4F378B]/20 text-[#CAC4D0] hover:text-[#E6E1E5] text-xs px-3.5 py-1.5 rounded-xl border border-[#49454F] transition cursor-pointer"
                  >
                    {copiedCode === selectedFile ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="font-mono text-[10px] font-bold text-emerald-400">COPIED</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="font-mono text-[10px]">COPY CODE</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Preformatted Code Content */}
                <div className="flex-1 overflow-auto rounded-2xl bg-[#1D1B20] border border-[#49454F] p-4 text-xs font-mono text-[#E6E1E5] select-all max-h-[500px]">
                  <pre className="whitespace-pre leading-relaxed font-mono">
                    <code>{getSelectedCodeText()}</code>
                  </pre>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* Tab 3: Interactive compiler guide */}
        {activeTab === "builder" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-fade-in">
            
            {/* Guide Step progression List (8 columns) */}
            <div className="lg:col-span-8 flex flex-col gap-5">
              
              <div className="bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl">
                <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-[#D0BCFF]" />
                  <span>Interactive APK Compiling Command Center</span>
                </h3>
                <p className="text-xs text-[#CAC4D0] leading-relaxed mb-6">
                  Follow these four standard execution steps on your developer workstation to bundle, build, minify, and compile the Flutter codebases into a native release APK file.
                </p>

                {/* Vertical progression steps */}
                <div className="flex flex-col gap-6 relative pl-3 border-l-2 border-[#49454F]">
                  
                  {/* Step 1 */}
                  <div className="relative flex flex-col gap-2">
                    <span className="absolute -left-7 top-0 w-6 h-6 rounded-full bg-[#4F378B] border-2 border-[#1D1B20] flex items-center justify-center text-xs font-bold text-white">
                      1
                    </span>
                    <h4 className="text-xs font-bold text-white">Configure Flutter Environment SDK</h4>
                    <p className="text-[11.5px] text-[#938F99] leading-relaxed">
                      Make sure standard Flutter SDK is loaded into your terminal session scope paths. Run doctor check to verify:
                    </p>
                    <div className="bg-[#141218] border border-[#49454F] rounded-xl p-3 flex justify-between items-center">
                      <code className="text-xs font-mono text-[#D0BCFF] bg-[#1D1B20] px-2.5 py-1 rounded-lg border border-[#49454F]/30">flutter doctor</code>
                      <button 
                        id="btn-copy-command-1"
                        onClick={() => handleCopyCode("flutter doctor", "fd")}
                        className="text-[10px] bg-[#2B2930] hover:bg-[#4F378B]/20 border border-[#49454F] text-[#CAC4D0] hover:text-[#E6E1E5] px-2.5 py-1.5 rounded-lg transition cursor-pointer"
                      >
                        {copiedCode === "fd" ? "Copied" : "Copy"}
                      </button>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="relative flex flex-col gap-2">
                    <span className="absolute -left-7 top-0 w-6 h-6 rounded-full bg-[#4F378B] border-2 border-[#1D1B20] flex items-center justify-center text-xs font-bold text-white">
                      2
                    </span>
                    <h4 className="text-xs font-bold text-white">Fetch Project Packages and Utilities</h4>
                    <p className="text-[11.5px] text-[#938F99] leading-relaxed">
                      Download all integrated Android libraries (including vocal synthesizers, share packs, storage access, local prefs states):
                    </p>
                    <div className="bg-[#141218] border border-[#49454F] rounded-xl p-3 flex justify-between items-center">
                      <code className="text-xs font-mono text-[#D0BCFF] bg-[#1D1B20] px-2.5 py-1 rounded-lg border border-[#49454F]/30">flutter pub get</code>
                      <button 
                        id="btn-copy-command-2"
                        onClick={() => handleCopyCode("flutter pub get", "fpg")}
                        className="text-[10px] bg-[#2B2930] hover:bg-[#4F378B]/20 border border-[#49454F] text-[#CAC4D0] hover:text-[#E6E1E5] px-2.5 py-1.5 rounded-lg transition cursor-pointer"
                      >
                        {copiedCode === "fpg" ? "Copied" : "Copy"}
                      </button>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="relative flex flex-col gap-2">
                    <span className="absolute -left-7 top-0 w-6 h-6 rounded-full bg-[#4F378B] border-2 border-[#1D1B20] flex items-center justify-center text-xs font-bold text-white">
                      3
                    </span>
                    <h4 className="text-xs font-bold text-white">Execute Native Release Compilation</h4>
                    <p className="text-[11.5px] text-[#938F99] leading-relaxed">
                      Compile everything. This instructs Dart to pre-compile variables to native ARM64 machine instructions and minifies file layout footprints:
                    </p>
                    <div className="bg-[#141218] border border-[#49454F] rounded-xl p-3 flex justify-between items-center">
                      <code className="text-xs font-mono text-[#D0BCFF] bg-[#1D1B20] px-2.5 py-1 rounded-lg border border-[#49454F]/30">flutter build apk --release</code>
                      <button 
                        id="btn-copy-command-3"
                        onClick={() => handleCopyCode("flutter build apk --release", "fba")}
                        className="text-[10px] bg-[#2B2930] hover:bg-[#4F378B]/20 border border-[#49454F] text-[#CAC4D0] hover:text-[#E6E1E5] px-2.5 py-1.5 rounded-lg transition cursor-pointer"
                      >
                        {copiedCode === "fba" ? "Copied" : "Copy"}
                      </button>
                    </div>
                  </div>

                  {/* Step 4 */}
                  <div className="relative flex flex-col gap-2">
                    <span className="absolute -left-7 top-0 w-6 h-6 rounded-full bg-[#4F378B] border-2 border-[#1D1B20] flex items-center justify-center text-xs font-bold text-white">
                      4
                    </span>
                    <h4 className="text-xs font-bold text-white">Extract Finished APK Packages</h4>
                    <p className="text-[11.5px] text-[#938F99] leading-relaxed">
                      Locate your final generated release Android package file at this folder location and deploy on any Android phone directly:
                    </p>
                    <div className="bg-[#141218] border border-[#D0BCFF]/25 p-4 rounded-xl border-dashed">
                      <code className="text-xs font-mono text-emerald-400">build/app/outputs/flutter-apk/app-release.apk</code>
                    </div>
                  </div>

                </div>
              </div>

            </div>

            {/* Quick troubleshooting panel Right (4 columns) */}
            <div className="lg:col-span-4 flex flex-col gap-5">
              
              {/* Build troubleshooting help cards */}
              <div className="bg-[#1D1B20] border border-[#49454F] rounded-[28px] p-6 shadow-xl flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#D0BCFF]" />
                  <span>Build Support Guide</span>
                </h3>

                <div className="flex flex-col gap-3">
                  
                  {/* Issue 1 */}
                  <div className="bg-[#141218] border border-[#49454F] p-4 rounded-2xl hover:border-[#D0BCFF]/40 transition duration-200">
                    <p className="text-xs font-bold text-white mb-1">Q: Does this build work offline?</p>
                    <p className="text-[10.5px] text-[#938F99] leading-relaxed">
                      A: Yes! It includes a dual sound engine. If no internet or API key is accessible, it seamlessly defaults to the device's hardware TTS language module, guaranteeing zero latency.
                    </p>
                  </div>

                  {/* Issue 2 */}
                  <div className="bg-[#141218] border border-[#49454F] p-4 rounded-2xl hover:border-[#D0BCFF]/40 transition duration-200">
                    <p className="text-xs font-bold text-white mb-1">Q: Gradle sync fails in Android Studio?</p>
                    <p className="text-[10.5px] text-[#938F99] leading-relaxed">
                      A: Ensure your active Java Development Kit (JDK) matches Oracle/OpenJDK version 17. Adjust your SDK paths inside Android Studio Settings preferences.
                    </p>
                  </div>

                  {/* Issue 3 */}
                  <div className="bg-[#141218] border border-[#49454F] p-4 rounded-2xl hover:border-[#D0BCFF]/40 transition duration-200">
                    <p className="text-xs font-bold text-white mb-1">Q: Where do I input my Gemini API key?</p>
                    <p className="text-[10.5px] text-[#938F99] leading-relaxed">
                      A: On the first launch of the APK, an elegant password input card is prompted natively. Entering your key unlocks premium cloud speech engines. Keys save securely inside the device's sandboxed local Shared Preferences storage.
                    </p>
                  </div>

                </div>
              </div>

              {/* Developer credentials warning card */}
              <div className="bg-gradient-to-br from-[#4F378B]/10 to-transparent border border-[#D0BCFF]/15 p-5 rounded-[20px] flex flex-col gap-2.5">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#D0BCFF]" />
                  <span className="text-xs font-bold text-white">Full Compatibility Guarantee</span>
                </div>
                <p className="text-[11px] text-[#938F99] leading-relaxed">
                  Every asset, color hex, code block, and pubspec dependency shown is structured 100% compliant with professional Material 3 engineering specifications, ensuring immediate successful Gradle integration.
                </p>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Footer System Status */}
      <footer className="mt-auto border-t border-[#49454F] bg-[#141218] py-4 px-6 flex justify-between items-center text-[11px] text-[#938F99]">
        <div className="flex items-center gap-2">
          <Smartphone className="w-3.5 h-3.5 text-[#D0BCFF]" />
          <span>Flutter Target Framework Android v21 - v34</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[10px] text-[#CAC4D0] bg-[#1D1B20] px-2.5 py-1 rounded-lg border border-[#49454F]">
          <span>COMPILER: STANDALONE (O3)</span>
        </div>
      </footer>

    </div>
  );
}
